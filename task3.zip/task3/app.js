const svg = d3.select('svg');
const bbox = svg.node().getBoundingClientRect();
const svgWidth = bbox.width;
const svgHeight = bbox.height;

/* Deine Lösung zu Aufgabe 1 Start */
svg.append("circle")
    .attr("r", 50)
    .attr("cx", 0)
    .attr("cy", 0)
    .classed("circle", true);
/* Deine Lösung zu Aufgabe 1 Ende */

/* Deine Lösung zu Aufgabe 2 Start */
svg.selectAll("circle")
    .transition()
    .duration(2000)
    .style("fill", "blue")
    .attr("cx", svgWidth + 50)
    .attr("cy", svgHeight + 50);
/* Deine Lösung zu Aufgabe 2 Ende */

/**
 * Returns a randomly filled circle object array
 */
function generateRandomData(size) {
    var data = [];
    for (var i = 0; i < size; i++) {
        data.push({
            cx: Math.random() * svgWidth,
            cy: Math.random() * svgHeight,
            r: Math.random() * 20
        });
    }
    return data;
}

const circleGroup = svg.append('g')
    .attr('id', 'circleGroup');


function addNewElements(data) {
    /* Deine Lösung zu Aufgabe 3 Start */
    d3.select("#circleGroup")
        .selectAll("circle")
        .data(data)
        .enter()
        .append("circle")
        .attr("cx", function(d) {
            return d.cx;
        })
        .attr("cy", function(d) {
            return d.cy;
        })
        .attr("r", function(d) {
            return d.r;
        })
        .classed("circle", true);
    /* Deine Lösung zu Aufgabe 3 Ende */
}


/*
 * Update Selection
 */
function updateExistingElements(data) {
    /* Deine Lösung zu Aufgabe 4 Start */
    d3.select("#circleGroup")
        .selectAll("circle")
        .transition()
        .duration(2000)
        .style("fill", "blue")
        .attr("cx", function(d) {
            return d.cx;
        })
        .attr("cy", function(d) {
            return d.cy;
        });

    /* Deine Lösung zu Aufgabe 4 Ende */
}


function removeResidualElements(data) {
    /* Deine Lösung zu Aufgabe 5 Start */
    d3.select("#circleGroup")
        .selectAll("circle")
        .data(data)
        .exit()
        .transition()
        .duration(2000)
        .attr("r", function(d) {
            return 0;
        })
        .remove();
    /* Deine Lösung zu Aufgabe 5 Ende */
}



function addListenerToCircles() {
    /* Deine Lösung zu Aufgabe 6 Start */
    d3.select("#circleGroup")
        .selectAll("circle")
        .on("mouseenter", function() {
            d3.select(this)
                .style("opacity", 0.5)
        })
        .on("mouseleave", function() {
            d3.select(this)
                .style("opacity", 1)
        })
        /* Deine Lösung zu Aufgabe 6 Ende */
}


/**
 * Updates the DOM based on passed data Array.
 */
function update(data) {
    addNewElements(data);
    updateExistingElements(data);
    removeResidualElements(data);
}

/**
 * Adds click listener to trigger the update function with
 * randomly generated data.
 */
d3.select('#updateData').on('click', function() {
    var random = Math.random() * 100;
    update(generateRandomData(random));
    addListenerToCircles();
});

var firstData = generateRandomData(100); //Ich habe das hier auf 100 gewechselt
update(firstData);
addListenerToCircles();